// Framework and third-party non-ui
import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import AppConfig from '../constants/AppConfig';
import ScreeningData from '../constants/ScreeningData';
import { getIndicatorData, layerHasData } from '../utilities/arcgisUtils';

// Setter Functions
import {
    _updateAreaOfInterestInfo,
    _updateMapView,
    _updateSelectedHazard,
    _updateStandardGeography,
} from './MapControllerSimple';
import AppRoutes from '../constants/AppRoutes';

export const AppContext = createContext();

export const emptyAreaOfInterestInfo = {
    geoId: null,
    geoName: null,
    geometry: null,
    allIndicators: null,
    buildingCode: null,
    oid: null,
};

export const AppContextProvider = ({ children }) => {
    const [t] = useTranslation();

    // ----- Data Filters -----
    const [selectedHazard, setSelectedHazard] = useState('extreme_temperature');
    const [selectedIndicatorId, setSelectedIndicatorId] = useState('TMAX100F');
    const [selectedModel, setSelectedModel] = useState(ScreeningData.models.rcp45);
    const [timeframe, setTimeframe] = useState(ScreeningData.timeframe.early);
    const [standardGeography, setStandardGeography] = useState(ScreeningData.standardGeographies.county);

    // ----- App State -----
    const [alertInfo, setAlertInfo] = useState();
    const [areaOfInterestInfo, setAreaOfInterestInfo] = useState(emptyAreaOfInterestInfo);

    const [indicators, setIndicators] = useState();
    const [page, setPage] = useState(AppRoutes.mapPage);

    // ----- JSAPI State -----
    const [mapView, setMapView] = useState(null);
    const [dataLayerView, setDataLayerView] = useState(null);
    const [aiannhaLayerView, setAiannhaLayerView] = useState(null);
    const [countiesLayerView, setCountiesLayerView] = useState(null);
    const [searchResult, setSearchResult] = useState(null);
    const [highlightHandle, setHighlightHandle] = useState(null);

    // JSAPI Setters

    const updateMapView = useCallback(
        async (mapView, webmap) => {
            try {
                // Add mapView to context
                await _updateMapView(
                    {
                        mapView,
                        setDataLayerView,
                        setAiannhaLayerView,
                        setCountiesLayerView,
                        standardGeography,
                    },
                    setMapView
                );
            } catch (error) {
                console.error('Error in updateMapView:', error);
                setAlertInfo({
                    type: 'error',
                    title: t('Alert.MapLoadError.title'),
                    message: t('Alert.MapLoadError.message'),
                });
            }
        },
        [setDataLayerView, setAiannhaLayerView, setCountiesLayerView, standardGeography]
    );

    const updateSelectedHazard = useCallback(
        async (value) => {
            await _updateSelectedHazard({ value, selectedIndicatorId, setSelectedIndicatorId }, setSelectedHazard);
        },
        [selectedIndicatorId, setSelectedIndicatorId]
    );

    const updateSearchResult = useCallback(
        async (value) => {
            if (!mapView) {
                return;
            }
            setSearchResult(value);
            if (!value || value === 'CLEAR') {
                mapView.graphics.removeAll();
                setAreaOfInterestInfo(emptyAreaOfInterestInfo);
            } else if (value?.result?.feature) {
                await _updateAreaOfInterestInfo({
                    pointGeometry: { ...value.result.feature.geometry.toJSON(), type: 'point' },
                    dataLayerView,
                    mapView,
                    standardGeography,
                    setAreaOfInterestInfo,
                });
            }
        },
        [mapView, dataLayerView, setAreaOfInterestInfo, standardGeography]
    );

    const updateStandardGeography = useCallback(
        async (value) => {
            // No change
            if (value === standardGeography) return;

            // Clear AOI info and graphics
            setAreaOfInterestInfo(emptyAreaOfInterestInfo);
            mapView.graphics.removeAll();
            setSearchResult(null);

            _updateStandardGeography(
                {
                    value,
                    aiannhaLayerView,
                    countiesLayerView,
                    setDataLayerView,
                    setAreaOfInterestInfo,
                },
                setStandardGeography
            );
        },
        [aiannhaLayerView, countiesLayerView, setDataLayerView, setAreaOfInterestInfo, mapView, standardGeography]
    );

    const updateHighlightHandle = useCallback(
        (handle) => {
            // Remove existing highlight
            if (highlightHandle?.remove) {
                highlightHandle?.remove();
            }
            setHighlightHandle(handle);
        },
        [highlightHandle]
    );
    useEffect(() => {
        /**
         * Effect to update the highlight on the map, when the areaOfInterestInfo changes
         */
        if (areaOfInterestInfo) {
            const handle =
                standardGeography === ScreeningData.standardGeographies.county
                    ? countiesLayerView?.highlight(areaOfInterestInfo.oid, { name: 'aoi' })
                    : aiannhaLayerView?.highlight(areaOfInterestInfo.oid, { name: 'aoi' });
            updateHighlightHandle(handle);
        } else {
            console.log;
            updateHighlightHandle(null);
        }
    }, [areaOfInterestInfo, countiesLayerView, aiannhaLayerView, standardGeography]);

    useEffect(() => {
        // Cleanup highlight handle on component unmount
        return () => {
            if (highlightHandle?.remove) {
                highlightHandle.remove();
            }
        };
    }, [highlightHandle]);

    useEffect(() => {
        if (selectedHazard && areaOfInterestInfo?.allIndicators) {
            const hazardIndicators = areaOfInterestInfo?.allIndicators.filter((indicator) => indicator[selectedHazard]);
            setIndicators(hazardIndicators);
        }
    }, [selectedHazard, areaOfInterestInfo]);

    return (
        <AppContext.Provider
            value={{
                // Data Filters
                selectedHazard,
                selectedIndicatorId,
                selectedModel,
                timeframe,
                standardGeography,
                updateSelectedHazard,
                setSelectedModel,
                setTimeframe,
                setStandardGeography,

                setSelectedIndicatorId,
                updateStandardGeography,

                // App State
                alertInfo,
                setAlertInfo,
                areaOfInterestInfo,
                setAreaOfInterestInfo,
                indicators,
                setIndicators,
                page,
                setPage,

                // JSAPI State
                mapView,
                updateMapView,
                dataLayerView,
                aiannhaLayerView,
                countiesLayerView,
                searchResult,
                updateSearchResult,
            }}
        >
            {children}
        </AppContext.Provider>
    );
};

export const useAppContext = () => {
    const appContext = useContext(AppContext);
    if (!appContext) throw new Error(`Cannot use 'useAppContext' outside of a AppContextProvider`);
    return appContext;
};
