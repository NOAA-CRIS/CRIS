import AppConfig from '../constants/AppConfig';
import FeatureLayer from '@arcgis/core/layers/FeatureLayer';
import MapSymbols from '../constants/MapSymbols';
import ScreeningData from '../constants/ScreeningData';
import { addLayersByItemId, getIndicatorData, unionExtents } from '../utilities/arcgisUtils';
import { emptyAreaOfInterestInfo } from './AppContextSimple';

const _updateMapView = async (args, setter) => {
    // do something with args if needed
    const { mapView, setDataLayerView, setAiannhaLayerView, setCountiesLayerView, standardGeography } = args;

    const countiesLayer = new FeatureLayer({
        // URL to the service
        url: AppConfig.datasets.counties.url,
        renderer: MapSymbols.emptyRenderer,
        visible: false,
        outFields: ['*'],
    });
    const aiannhaLayer = new FeatureLayer({
        // URL to the service
        url: AppConfig.datasets.aiannha.url,
        renderer: MapSymbols.emptyRenderer,
        visible: false,
        outFields: ['*'],
    });

    mapView.map.add(aiannhaLayer);
    mapView.map.add(countiesLayer);
    let itemIds = [];
    ScreeningData.indicators.forEach((indicator) => {
        if (indicator.layerIds) {
            indicator.layerIds.forEach((id) => itemIds.push(id));
        }
        if (indicator.modelTimeframeLayers) {
            Object.values(indicator.modelTimeframeLayers).forEach((id) => itemIds.push(id));
        }
        if (indicator.overlayLayers) {
            indicator.overlayLayers.forEach((id) => itemIds.push(id));
        }
    });
    await addLayersByItemId(mapView, itemIds, false);
    const aiannhaLayerView = await mapView.whenLayerView(aiannhaLayer);
    const countiesLayerView = await mapView.whenLayerView(countiesLayer);

    setAiannhaLayerView(aiannhaLayerView);
    setCountiesLayerView(countiesLayerView);

    if (standardGeography === ScreeningData.standardGeographies.county) {
        setDataLayerView(countiesLayerView);
    } else if (standardGeography === ScreeningData.standardGeographies.aiannha) {
        setDataLayerView(aiannhaLayerView);
    } else {
        setDataLayerView(countiesLayerView);
    }

    await setter(mapView);
};

const _updateSelectedHazard = async (args, setter) => {
    const { value, selectedIndicatorId, setSelectedIndicatorId } = args;
    /**
     * Some indicators are shared across multiple hazards.
     * When switching hazards, ensure the selected indicator is valid for the new hazard.
     * If not, set it to the first available indicator for that hazard.
     */
    const selectedIndicator = ScreeningData.indicators.find((indicator) => indicator.id === selectedIndicatorId);

    if (!selectedIndicator || !selectedIndicator[value]) {
        const firstIndicator = ScreeningData.indicators
            .sort((a, b) => a[value] - b[value])
            .find((indicator) => indicator[value]);
        if (firstIndicator) {
            setSelectedIndicatorId(firstIndicator.id);
        }
    }
    await setter(value);
};

const _updateStandardGeography = async (args, setter) => {
    const { value, aiannhaLayerView, countiesLayerView, setDataLayerView } = args;

    let newLayerView = null;
    countiesLayerView.layer.visible = false;
    aiannhaLayerView.layer.visible = false;
    countiesLayerView.layer.renderer = MapSymbols.emptyRenderer;
    aiannhaLayerView.layer.renderer = MapSymbols.emptyRenderer;

    if (value === ScreeningData.standardGeographies.county) {
        newLayerView = countiesLayerView;
    }
    if (value === ScreeningData.standardGeographies.aiannha) {
        newLayerView = aiannhaLayerView;
    }

    countiesLayerView.layer.visible = true;
    aiannhaLayerView.layer.visible = true;

    await setter(value);
    setDataLayerView(newLayerView);
};

const _updateAreaOfInterestInfo = async (args) => {
    // do something with args if needed
    const { pointGeometry, dataLayerView, mapView, standardGeography, setAreaOfInterestInfo } = args;

    mapView.graphics.removeAll();

    mapView.graphics.add({
        geometry: pointGeometry,
        symbol: MapSymbols.location,
    });
    if (pointGeometry && dataLayerView) {
        const indicatorDataResult = await getIndicatorData({
            layerView: dataLayerView,
            geometry: pointGeometry,
            mapView: mapView,
        });

        const indicators = indicatorDataResult.data;
        const standardGeoGeometry = indicatorDataResult.geometry;
        if (standardGeoGeometry && mapView) {
            const extent = unionExtents({
                pologons: [standardGeoGeometry],
                expandFactor: AppConfig.zoomToGeomExtentFactor ? AppConfig.zoomToGeomExtentFactor : 1.5,
            });
            mapView.goTo({
                target: extent,
            });
        }
        const { geoIdField, countyNameField, aiannhaNameField, stateAbbrField } = ScreeningData.standardGeographies;
        if (indicators.length) {
            const indicator = indicators[0];
            setAreaOfInterestInfo({
                allIndicators: indicators,
                geoId: indicator[geoIdField],
                geoName:
                    standardGeography === ScreeningData.standardGeographies.county
                        ? `${indicator[countyNameField]}, ${indicator[stateAbbrField]}`
                        : indicator[aiannhaNameField],
                geometry: standardGeoGeometry,
                buildingCode: indicator[ScreeningData.flags.buildingCode.fieldName],
                oid: indicator.OID,
            });
        } else {
            setAreaOfInterestInfo(emptyAreaOfInterestInfo);
        }
    } else {
        setAreaOfInterestInfo(emptyAreaOfInterestInfo);
    }
};

export { _updateMapView, _updateSelectedHazard, _updateStandardGeography, _updateAreaOfInterestInfo };
