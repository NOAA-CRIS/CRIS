**Extreme Heat**

**Annual days with maximum temperature ≥ 90°F** \[and 95°F, 100°, and 105°F\]

For the 30 years from 1951 to 1980, for locations in {{geoName}}, models estimated an average of {{HISTORIC_MEAN}} days per year when the highest temperature of the day reached 90°F or higher.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the number of days reaching at least 90°F will increase to:

-   an average of {{RCP45EARLY_MEAN}} days per year early this century, from 2011 to 2040;
-   an average of {{RCP45MID_MEAN}} days per year by the middle of this century, from 2041-2070; and
-   an average of {{RCP45LATE_MEAN}} days per year at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the number of days that reach 90°F or higher will further increase to:

-   an average of {{RCP85EARLY_MEAN}} days per year early this century, from 2011 to 2040;
-   an average of {{RCP85MID_MEAN}} days per year by the middle of this century, from 2041-2070; and
-   an average of {{RCP85LATE_MEAN}} days per year at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.

**Annual single highest maximum temperature**

For the 30 years from 1951 to 1980, for locations in {{geoName}}, models estimated that the highest temperature of the year was{{HISTORIC_MEAN}}°F.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the highest temperature of the year at locations in this county will increase to:

-   {{RCP45EARLY_MEAN}}°F during the early part of this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}}°F by the middle of this century, from 2041-2070; and
-   {{RCP45LATE_MEAN}}°F at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the highest temperature of the year will further increase to:

-   {{RCP85EARLY_MEAN}}°F during the early part of this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}}°F by the middle of this century, from 2041-2070; and
-   {{RCP85LATE_MEAN}}°F at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.

**Annual highest maximum temperature averaged over a 5-day period**

For the 30 years from 1951 to 1980, for locations in {{geoName}}, models estimated the typical afternoon temperature during the hottest week of the year was {{HISTORIC_MEAN}}°F.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the 5-day average maximum temperature during the hottest week of the year at locations in this county will increase to:

-   {{RCP45EARLY_MEAN}}°F during the early part of this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}}°F by the middle of this century, from 2041-2070; and
-   {{RCP45LATE_MEAN}}°F at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the 5-day average maximum temperature during the hottest week of the year will further increase to:

-   {{RCP85EARLY_MEAN}}°F during the early part of this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}}°F by the middle of this century, from 2041-2070; and
-   {{RCP85LATE_MEAN}}°F at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.

**Cooling-Degree Days (CDD)**

For the 30 years from 1951 to 1980, for locations in {{geoName}}, models estimated the measure of energy it took to cool building interiors to 65°F during warm seasons was {{HISTORIC_MEAN}} degree days.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the annual average cooling-degree days at locations in this county will increase to:

-   {{RCP45EARLY_MEAN}} degree days during the early part of this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} degree days by the middle of this century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} degree days at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the annual average cooling-degree days will further increase to:

-   {{RCP85EARLY_MEAN}} degree days during the early part of this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} degree days by the middle of this century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} degree days at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.

**Drought**

**Average Annual Total Precipitation**

For the 30 years from 1951 to 1980, models estimate that locations in {{geoName}}, received an average total depth of rain and snow of {{HISTORIC_MEAN}} inches.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the average annual total precipitation will \[increase / decrease\] to:

-   {{RCP45EARLY_MEAN}} inches early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} inches by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} inches at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the average annual total precipitation will further \[increase / decrease\] to:

-   {{RCP85EARLY_MEAN}} inches early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} inches by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} inches at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.

**Days per year with precipitation (wet days)**

For the 30 years from 1951 to 1980, models estimate that for locations in {{geoName}}, the longest stretch of days per year with precipitation (wet days) was {{HISTORIC_MEAN}} days.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project a year’s longest stretch of days with precipitation will \[increase / decrease\] to:

-   {{RCP45EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project a year’s longest stretch of days with precipitation will further \[increase / decrease\] to:

-   {{RCP85EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.

**Days per year with no precipitation (dry days)**

For the 30 years from 1951 to 1980, models estimate that locations in {{geoName}}, averaged {{HISTORIC_MEAN}} days per year with no measurable precipitation (dry days)\].

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the average number of days per year with no rain or snow will \[increase / decrease\] to:

-   {{RCP45EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the average number of days per year with no precipitation will further \[increase / decrease\] to:

-   {{RCP85EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.

**Maximum number of consecutive dry days**

For the 30 years from 1951 to 1980, models estimate that for locations in {{geoName}}, a year’s longest stretch of days without precipitation was {{HISTORIC_MEAN}} days.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the longest stretch of days without precipitation will \[increase / decrease\] to:

-   {{RCP45EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the longest stretch of days without precipitation will further \[increase / decrease\] to:

-   {{RCP85EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.

**Wildfire**

**Days per year with no precipitation (dry days)**

For the 30 years from 1951 to 1980, models estimate that locations in {{geoName}}, averaged {{HISTORIC_MEAN}} days per year with no measurable precipitation (dry days)\].

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the average number of days per year with no rain or snow will \[increase / decrease\] to:

-   {{RCP45EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the average number of days per year with no precipitation will further \[increase / decrease\] to:

-   {{RCP85EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.

**Maximum number of consecutive dry days**

For the 30 years from 1951 to 1980, models estimate that for locations in {{geoName}}, a year’s longest stretch of days without precipitation was {{HISTORIC_MEAN}} days.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the longest stretch of days without precipitation will \[increase / decrease\] to:

-   {{RCP45EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the longest stretch of days without precipitation will further \[increase / decrease\] to:

-   {{RCP85EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.

**Days per year with precipitation (wet days)**

For the 30 years from 1951 to 1980, models estimate that for locations in {{geoName}}, the longest stretch of days per year with precipitation (wet days) was {{HISTORIC_MEAN}} days.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project a year’s longest stretch of days with precipitation will \[increase / decrease\] to:

-   {{RCP45EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project a year’s longest stretch of days with precipitation will further \[increase / decrease\] to:

-   {{RCP85EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.

**Flooding**

**Average Annual Total Precipitation**

For the 30 years from 1951 to 1980, models estimate that locations in {{geoName}}, received an average total depth of rain and snow of {{HISTORIC_MEAN}} inches.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the average annual total precipitation will \[increase / decrease\] to:

-   {{RCP45EARLY_MEAN}} inches early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} inches by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} inches at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the average annual total precipitation will further \[increase / decrease\] to:

-   {{RCP85EARLY_MEAN}} inches early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} inches by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} inches at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.

**Days Per Year with Precipitation (Wet Days)**  
See above ^

**Maximum Number of Consecutive Wet Days**  
See above ^

**Annual Days with Total Precipitation ≥ 1 inch** \[and 2 inches and 3 inches\]

For the 30 years from 1951 to 1980, models estimate that locations in {{geoName}}, had {{HISTORIC_MEAN}} days per year with \[1 inch\] or more precipitation.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the average annual number of days with \[1 inch\] or more of precipitation will \[increase / decrease\] to:

-   {{RCP45EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the number of days per year with \[1 inch\] or more of precipitation will further \[increase / decrease\] to:

-   {{RCP85EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.

**Annual Days that Exceed 99th Percentile Precipitation**

For the 30 years from 1951 to 1980, models estimate that locations in {{geoName}}, averaged {{HISTORIC_MEAN}} days per year with precipitation in the top 1% of historical precipitation totals.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the annual number of days with precipitation in the top 1% of historic precipitation totals will \[increase / decrease\] to:

-   {{RCP45EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the number of days per year with precipitation in the top 1% of historic precipitation totals will further \[increase / decrease\] to:

-   {{RCP85EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.

**Days with Maximum Temperature \< 32°F**

Fewer days with temperatures below freezing means more days with melting, which can increase local flood risk—particularly during rain-on-snow events.

For the 30 years from 1951 to 1980, models estimate that locations in {{geoName}}, averaged {{HISTORIC_MEAN}} days per year when the highest temperature was below 32°F.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the annual number of days with a maximum temperature below 32°F will decrease to:

-   {{RCP45EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the annual number of days with a maximum temperature below 32°F will further decrease to:

-   {{RCP85EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.

## **Coastal Inundation**

**Percent of selected county impacted by global sea level rise**

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project that more land area in {{geoName}}, will be impacted by sea level rise — specifically, an increase of:

-   {{RCP45EARLY_MEAN}} percent early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} percent by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} percent at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the percent of impacted land area will further increase to:

-   {{RCP85EARLY_MEAN}} percent early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} percent by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} percent at the end of this century, from 2071 to 2100\.

Note: This dataset may be more meaningful if viewed in the “Map Exploration” tab to see the geographical extent of the impacted lands. Also, the interpretation above shows the average projections; to see the full range of all projections, check the Chart or Table tabs.

**Sea level change**

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project that mean sea level in {{geoName}}, will rise by:

-   {{RCP45EARLY_MEAN}} feet by early this century (the 2030s);
-   {{RCP45MID_MEAN}} feet by mid century (the 2060s); and
-   {{RCP45LATE_MEAN}} feet by the end of this century (the 2090s).

These projections are based on an intermediate-low sea level rise scenario, which represents the lower bound of likely sea level rise given current observations and warming trends. This scenario is linked to a wide range of emissions and socioeconomic pathways. Because low confidence processes (e.g., rapid ice sheet melt) are not important to this scenario, the range of possible sea level rise after 2100 does not expand significantly.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project that mean local sea level will further rise by:

-   {{RCP85EARLY_MEAN}} feet by early this century (the 2030s);
-   {{RCP85MID_MEAN}} feet by mid century (the 2060s); and
-   {{RCP85LATE_MEAN}} feet by the end of this century (the 2090s).

These projections are based on an intermediate-high sea level rise scenario, which reflects conditions with **rapid ice sheet loss**, higher emissions, and greater warming. This will likely produce a wider range of outcomes by 2050–2100 due to uncertainties in warming and ice melt. Sea levels will likely rise even more from 2100 to 2150t.

Note that this interpretation provides projected mean (50%) values. To see the full range of uncertainty bounds (17% and 83%) for the projections, check the Chart or Table tabs
