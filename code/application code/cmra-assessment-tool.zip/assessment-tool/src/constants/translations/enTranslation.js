const enTranslation = {
    SignInPage: {
        Login: 'Climate Mapping For Resilience and Adaptation',
        SignIn: 'Sign In',
        SignOut: 'Sign Out',
        Error: 'Access Denied',
    },
    App: {
        Title: 'Climate Mapping For Resilience and Adaptation',
        LinkToPortal: 'CMRA Hub',
        UserGuide: 'User Guide',
        DataSources: 'Data Sources',
        BackButtonText: 'Back',
    },
    Alert: {
        NoData: {
            Title: 'Data Not Found',
            Message: {
                default: 'Select a {{standardGeography}} within the United States',
                aiannha: 'Select an American Indian/Alaska Native/Native Hawaiian Area, shown in gray.',
            },
        },
        RenderError: {
            Title: 'Error Displaying Data',
            Message: 'An Error has occurred, please modify your selection.',
        },
        MapLoadError: {
            title: 'Error Loading Map',
            message: 'An error occurred while loading the map. Please try again later.',
        },
        DeviceSupport: {
            Title: 'Device not supported',
            P1: 'We are sorry, and the CMRA assessment tool currently does not support mobile devices or anything that has a smaller screen resolution than 700 x 540. ',
            P2: 'You can go back to the CMRA Portal, or use a different device to visit the assessment tool again.',
            Button1: 'View CRMA Portal',
            Button2: 'Access User Guide',
        },
    },
    Header: {
        Button: 'Get Complete Report',
        ButtonDisabled: 'Reports are not available for Census Tracts.',
        ButtonDisabledNoSelection: 'Please select an area to generate a report.',
        MobileMenuBtn: {
            Open: 'Open menu',
            Close: 'Close menu',
        },
    },
    Home: {
        SearchMap: 'Search Map',
        Details:
            'Data and maps available in this tool are downscaled results from global climate models. Results for selected geographies indicate how local exposure to five common climate-related hazards is projected to change through this century.  Assessing climate vulnerability and risk to your local assets will require additional information that is not available in this tool.',
        DetailsLinkText:
            'See the U.S. Climate Resilience Toolkit’s Steps to Resilience framework for more information.',
    },
    Search: {
        BrowseMap: 'Select Location',
        Submit: 'Check Climate Exposure',
        ProjectLocation: 'Project Location',
        MapPin: 'Choose a location on the map',
    },
    HazardList: {
        Title: 'Climate Hazards',
    },
    IndicatorList: {
        Title: 'Climate Projections for',
        ProjectedBy: 'Projected by',
    },
    IndicatorItem: {
        PositiveDelta: '+ {{value}} since 1976-2005',
        NegativeDelta: '- {{value}} since 1976-2005',
        NoDelta: 'No change since 1976-2005',
    },
    IndicatorDetails: {
        Title: 'Indicator Details',
        Tab1: 'Chart',
        Tab2: 'Table',
        Tab3: 'Details',
        MeanValueLabel: 'Mean Estimated Value',
        ValueLabel: 'Estimated Value',
    },
    Flags: {
        Disadvantaged: 'Disadvantaged Community',
        DisadvantagedPopulation: '{{popPercent}}% of Population in Disadvantaged Communities',
        NonDisadvantaged: 'Not a Disadvantaged Community',
        DisadvantagedTooltip:
            'According to the Climate and Economic Justice Screening Tool (CEJST), communities are considered to be disadvantaged if they are in census tracts that meet the thresholds for at least one of the tool’s categories of burden, or if they are on land within the boundaries of Federally Recognized Tribes, including Alaska Native Villages.\n\nFederal agencies will use CEJST to help identify communities that can benefit from investments in climate, clean energy, and related areas.\n\nClick the button to learn more about CEJST.',
        BuildingCode: 'Building Code: {{buildingCode}}',
        BuildingCodeTooltip:
            'Resistant  — 100% of the county is required to adhere to a hazard-resistant building code\n\nPartially Resistant – portions of the county are required to adhere to a hazard-resistant building code\n\nLower resistance – no part of the county is required to adhere to a hazard-resistant building code\n\nClick the button for more information.',
    },
    Inputs: {
        Hazards: {
            ShortLabel: 'Hazards',
        },
        Indicators: {
            ShortLabel: 'Indicators',
        },
        Models: {
            ShortLabel: 'Scenario',
        },
        Timeframe: {
            Future: 'Prediction Years',
            All: 'Timeframe',
        },
    },
    Map: {
        Popup: {
            actionButton1: 'Explore Data',
            actionButton2: 'Select Location',
        },
    },
    MapControls: {
        WelcomeIntro: {
            Title: 'To get started',
            P1: 'Select an area.',
            P2: 'Apply filters. Use the ‘Explore Data’ button after filtering for more details on area.',
            ButtonClose: 'close welcome message',
        },
        MinimizeBtn: {
            Open: 'Open filters',
            Close: 'Close filters',
        },
        ClearBtn: 'Clear Selection',
        CloseBtn: {
            Close: 'Clear selected area',
        },
        InnerActionsMinimizeBtn: {
            Title: 'Explore Data',
        },
        InnerActionsBtn1: {
            Title: 'Explore Data',
        },
    },
    NavigationTab: {
        Details: 'Climate Projections',
        DetailsTooltip: 'Climate projections for three periods and two scenarios',
        Map: 'Map Exploration',
    },
    StandardGeographySelect: {
        Info: 'Search Area',
    },
    Legend: {
        Header: 'Climate Indicator Value:',
        Tribal: 'Tribal Area',
        Message: 'Click on the map to get information for the selected indicator',
        LeftText: 'Low',
        RightText: 'High',
    },
    Data: {
        Time: {
            HISTORIC: {
                LongLabel: 'Modeled History (1976-2005)',
                Label: 'Modeled History',
                Years: '1976-2005',
            },
            EARLY: {
                Label: 'Early Century',
                Years: '2015–2044',
            },
            MID: {
                Label: 'Mid Century',
                Years: '2035–2064',
            },
            LATE: {
                Label: 'Late Century',
                Years: '2070–2099',
            },
        },
        Stats: {
            MAX: 'Maximum',
            MEAN: 'Mean',
            MIN: 'Minimum',
            PROJECTION: 'Projection',
        },
        Models: {
            RCP45: {
                Short: 'SSP2-4.5',
                Label: 'Lower Emissions Scenario',
                LongLabel: 'Lower Emissions Scenario (SSP2-4.5)',
                ShortLabel: 'Lower emissions (SSP2-4.5)',
                Tooltip:
                    'The Lower Emissions Scenario is a possible future in which humans drastically reduce their use of fossil fuels, reducing global emissions of heat-trapping gases to zero by 2040. This scenario is known as SSP2-4.5.',
            },
            RCP85: {
                Short: 'SSP5-8.5',
                Label: 'Higher Emissions Scenario',
                LongLabel: 'Higher Emissions Scenario (SSP5-8.5)',
                ShortLabel: 'Higher emissions (SSP5-8.5)',
                Tooltip:
                    'The Higher Emissions Scenario is a possible future in which humans continue increasing emissions of heat-trapping gases from fossil fuels through 2100. This scenario is known as SSP5-8.5.',
            },
        },
        StandardGeographies: {
            COUNTY: 'County',
            TRACT: 'Census Tract',
            aiannha: 'Tribal Area',
            aiannha_Tip: 'American Indian/Alaska Native/Native Hawaiian Area',
        },
    },
    Hazards: {
        drought: {
            Title: 'Drought',
        },
        extreme_temperature: {
            Title: 'Extreme Heat',
        },
        fire: {
            Title: 'Wildfire',
        },
        flooding_inland: {
            Title: 'Flooding',
        },
        flooding_costal: {
            Title: 'Coastal Inundation',
        },
    },
    Indicators: {
        SLRIMPACT: {
            Title: 'Percent of selected {{standardGeography}} impacted by global sea level rise',
            Name: 'Sea Level Rise',
            LeveedLegend: 'Levee Areas',
            Details: 'Percent of selected area impacted by global sea level rise',
            Prefix: '',
            Postfix: '%',
            ValueCard: 'Area Impacted by Sea Level Rise',
            LongText: `If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project that more land area in {{geoName}}, will be impacted by sea level rise — specifically, an increase of:

        -   {{RCP45EARLY_MEAN}} percent early this century, from 2011 to 2040;
        -   {{RCP45MID_MEAN}} percent by mid-century, from 2041-2070; and
        -   {{RCP45LATE_MEAN}} percent at the end of this century, from 2071 to 2100\.

        Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the percent of impacted land area will further increase to:

        -   {{RCP85EARLY_MEAN}} percent early this century, from 2011 to 2040;
        -   {{RCP85MID_MEAN}} percent by mid-century, from 2041-2070; and
        -   {{RCP85LATE_MEAN}} percent at the end of this century, from 2071 to 2100\.

        Note: This dataset may be more meaningful if viewed in the “Map Exploration” tab to see the geographical extent of the impacted lands. Also, the interpretation above shows the average projections; to see the full range of all projections, check the Chart or Table tabs.
        `,
        },
        MIN_SLR: {
            Title: 'Minimum local sea level rise (Feet)',
            Details: 'Minimum local sea level rise relative to 2000 (in feet)',
            Prefix: '',
            Postfix: 'Feet',
            LongText: `If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the minimum local sea level rise will \[increase / decrease\] to:

-   {{RCP45EARLY_MIN_SLR}} feet early this century, from 2011 to 2040;
-   {{RCP45MID_MIN_SLR}} feet by mid-century, from 2041-2070; and
-   {{RCP45LATE_MIN_SLR}} feet at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the minimum local sea level rise will \[increase / decrease\] to:

-   {{RCP85EARLY_MIN_SLR}} feet early this century, from 2011 to 2040;
-   {{RCP85MID_MIN_SLR}} feet by mid-century, from 2041-2070; and
-   {{RCP85LATE_MIN_SLR}} feet at the end of this century, from 2071 to 2100\.
Note: This dataset may be more meaningful if viewed in the “Map Exploration” tab to see the geographical extent of the impacted lands. Also, the interpretation above shows the average projections; to see the full range of all projections, check the Chart or Table tabs.`,
        },
        MEAN_SLR: {
            Title: 'Mean local sea level rise (Feet)',
            Details: 'Mean local sea level rise relative to 2000 (in feet)',
            Prefix: '',
            Postfix: 'Feet',
            LongText: `If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the mean local sea level rise will \[increase / decrease\] to:

-   {{RCP45EARLY_MEAN_SLR}} feet early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN_SLR}} feet by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN_SLR}} feet at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the mean local sea level rise will \[increase / decrease\] to:

-   {{RCP85EARLY_MEAN_SLR}} feet early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN_SLR}} feet by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN_SLR}} feet at the end of this century, from 2071 to 2100\.
Note: This dataset may be more meaningful if viewed in the “Map Exploration” tab to see the geographical extent of the impacted lands. Also, the interpretation above shows the average projections; to see the full range of all projections, check the Chart or Table tabs.`,
        },
        MAX_SLR: {
            Title: 'Maximum local sea level rise (Feet)',
            Details: 'Maximum local sea level rise relative to 2000 (in feet)',
            Prefix: '',
            Postfix: 'Feet',
            LongText: `If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the maximum local sea level rise will \[increase / decrease\] to:

-   {{RCP45EARLY_MAX_SLR}} feet early this century, from 2011 to 2040;
-   {{RCP45MID_MAX_SLR}} feet by mid-century, from 2041-2070; and
-   {{RCP45LATE_MAX_SLR}} feet at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the maximum local sea level rise will \[increase / decrease\] to:

-   {{RCP85EARLY_MAX_SLR}} feet early this century, from 2011 to 2040;
-   {{RCP85MID_MAX_SLR}} feet by mid-century, from 2041-2070; and
-   {{RCP85LATE_MAX_SLR}} feet at the end of this century, from 2071 to 2100\.
Note: This dataset may be more meaningful if viewed in the “Map Exploration” tab to see the geographical extent of the impacted lands. Also, the interpretation above shows the average projections; to see the full range of all projections, check the Chart or Table tabs.`,
        },
        CURRENT_INLAND_FLOOD: {
            Title: 'Current flood hazard',
            FLOOD_PCT_100: {
                Name: '100-year flood zone',
                Details: 'Area in 100-year flood zone',
                Prefix: '',
                Postfix: '%',
            },
            FLOOD_PCT_500: {
                Name: '500-year flood zone',
                Details: 'Area in 500-year flood zone',
                Prefix: '',
                Postfix: '%',
            },
            FLOOD_PCT_UND: {
                Name: 'Flood hazard unknown',
                Details: 'Area flood hazard unknown',
                Prefix: '',
                Postfix: '%',
            },
        },

        CDD: {
            Title: 'Cooling-degree days (CDD)',
            Details:
                'Cooling degree days (Estimate of cooling needed to maintain a comfortable temperature. Calculated as the sum of the degrees above 65 °F per day per year)',
            Prefix: '',
            Postfix: 'Degree Days',
            LongText: `For the 30 years from 1951 to 1980, for locations in {{geoName}}, models estimated the measure of energy it took to cool building interiors to 65°F during warm seasons was {{HISTORIC_MEAN}} degree days.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the annual average cooling-degree days at locations in this county will increase to:

-   {{RCP45EARLY_MEAN}} degree days during the early part of this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} degree days by the middle of this century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} degree days at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the annual average cooling-degree days will further increase to:

-   {{RCP85EARLY_MEAN}} degree days during the early part of this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} degree days by the middle of this century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} degree days at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.`,
        },
        CONSECDD: {
            Title: 'Maximum number of consecutive dry days',
            Details:
                'Annual maximum number of consecutive dry days (days with total precipitation less than 0.01 inches)',
            Prefix: '',
            Postfix: 'Days',
            LongText: `For the 30 years from 1951 to 1980, models estimate that for locations in {{geoName}}, a year’s longest stretch of days without precipitation was {{HISTORIC_MEAN}} days.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the longest stretch of days without precipitation will \[increase / decrease\] to:

-   {{RCP45EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the longest stretch of days without precipitation will further \[increase / decrease\] to:

-   {{RCP85EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.`,
        },
        CONSECWD: {
            Title: 'Maximum number of consecutive wet days',
            Details:
                'Annual maximum number of consecutive wet days (days with total precipitation greater than or equal to 0.01 inches)',
            Prefix: '',
            Postfix: 'Days',
            LongText: `For the 30 years from 1951 to 1980, models estimate that for locations in {{geoName}}, the longest stretch of days per year with precipitation (wet days) was {{HISTORIC_MEAN}} days.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project a year’s longest stretch of days with precipitation will \[increase / decrease\] to:

-   {{RCP45EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project a year’s longest stretch of days with precipitation will further \[increase / decrease\] to:

-   {{RCP85EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.`,
        },
        PR_ANNUAL: {
            Title: 'Average annual total precipitation',
            Details: 'Average annual total precipitation (inches)',
            Prefix: '',
            Postfix: 'Inches',
            LongText: `For the 30 years from 1951 to 1980, models estimate that locations in {{geoName}}, received an average total depth of rain and snow of {{HISTORIC_MEAN}} inches.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the average annual total precipitation will \[increase / decrease\] to:

-   {{RCP45EARLY_MEAN}} inches early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} inches by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} inches at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the average annual total precipitation will further \[increase / decrease\] to:

-   {{RCP85EARLY_MEAN}} inches early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} inches by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} inches at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.
`,
        },
        PR1IN: {
            Title: 'Annual days with total precipitation > 1 inch',
            Details: 'Annual number of days with total precipitation greater than 1 inch',
            Prefix: '',
            Postfix: 'Days',
            LongText: `For the 30 years from 1951 to 1980, models estimate that locations in {{geoName}}, had {{HISTORIC_MEAN}} days per year with \[1 inch\] or more precipitation.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the average annual number of days with \[1 inch\] or more of precipitation will \[increase / decrease\] to:

-   {{RCP45EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the number of days per year with \[1 inch\] or more of precipitation will further \[increase / decrease\] to:

-   {{RCP85EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.`,
        },
        PR2IN: {
            Title: 'Annual days with total precipitation > 2 inches',
            Details: 'Annual number of days with total precipitation greater than 2 inches',
            Prefix: '',
            Postfix: 'Days',
            LongText: `For the 30 years from 1951 to 1980, models estimate that locations in {{geoName}}, had {{HISTORIC_MEAN}} days per year with \[1 inch\] or more precipitation.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the average annual number of days with \[1 inch\] or more of precipitation will \[increase / decrease\] to:

-   {{RCP45EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the number of days per year with \[1 inch\] or more of precipitation will further \[increase / decrease\] to:

-   {{RCP85EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.`,
        },
        PR3IN: {
            Title: 'Annual days with total precipitation > 3 inches',
            Details: 'Annual number of days with total precipitation greater than 3 inches',
            Prefix: '',
            Postfix: 'Days',
            LongText: `For the 30 years from 1951 to 1980, models estimate that locations in {{geoName}}, had {{HISTORIC_MEAN}} days per year with \[1 inch\] or more precipitation.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the average annual number of days with \[1 inch\] or more of precipitation will \[increase / decrease\] to:

-   {{RCP45EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the number of days per year with \[1 inch\] or more of precipitation will further \[increase / decrease\] to:

-   {{RCP85EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.`,
        },
        PR99: {
            Title: 'Daily precipitation 99th percentile value',
            Details: 'Daily precipitation 99th percentile value, calculated with reference to the 1951-1980 average',
            Prefix: '',
            Postfix: 'Inches',
            LongText: `Daily precipitation 99th percentile value, calculated with reference to the 1951-1980 average, is {{HISTORIC_MEAN}} inches for locations in {{geoName}}`,
        },
        PRABOVE99: {
            Title: 'Daily precipitation that exceed 99th percentile',
            Details:
                ' Daily precipitation total in inches exceeding the 99th percentile of all totals modeled for 1951-1980',
            Prefix: '',
            Postfix: 'Inches',
            LongText: `For the 30 years from 1951 to 1980, models estimate that locations in {{geoName}}, averaged {{HISTORIC_MEAN}} inches in excess of the top 1% of historical precipitation totals ({{PR99}} inches).

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the annual number of inches of precipitation in excess of the top 1% of historic precipitation totals ({{PR99}} inches) will \[increase / decrease\] to:

-   {{RCP45EARLY_MEAN}} inches early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} inches by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} inches at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the annual number of inches of precipitation in excess of the top 1% of historic precipitation totals ({{PR99}} inches) will further \[increase / decrease\] to:

-   {{RCP85EARLY_MEAN}} inches early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} inches by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} inches at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.`,
        },
        PRDAYS99: {
            Title: 'Annual number of days with precipitation that exceed 99th percentile',
            Details:
                'Annual number of days with precipitation exceeding the 99th percentile, calculated with reference to the 1951-1980 average',
            Prefix: '',
            Postfix: 'Days',
            LongText: `For the 30 years from 1951 to 1980, models estimate that locations in {{geoName}}, averaged {{HISTORIC_MEAN}} days per year with precipitation in the top 1% of historical precipitation totals ({{PR99}} inches).

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the annual number of days with precipitation in the top 1% of historic precipitation totals ({{PR99}} inches) will \[increase / decrease\] to:

-   {{RCP45EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the number of days per year with precipitation in the top 1% of historic precipitation totals ({{PR99}} inches) will further \[increase / decrease\] to:

-   {{RCP85EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.`,
        },
        PR0IN: {
            Title: 'Days per year with precipitation (wet days)',
            Details: 'Annual number of days with total precipitation greater than 0.01 inches',
            Prefix: '',
            Postfix: 'Days',
            LongText: `For the 30 years from 1951 to 1980, models estimate that for locations in {{geoName}}, the longest stretch of days per year with precipitation (wet days) was {{HISTORIC_MEAN}} days.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project a year’s longest stretch of days with precipitation will \[increase / decrease\] to:

-   {{RCP45EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project a year’s longest stretch of days with precipitation will further \[increase / decrease\] to:

-   {{RCP85EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.`,
        },
        PRLT0IN: {
            Title: 'Days per year with no precipitation (dry days)',
            Details: 'Annual number of days with total precipitation less than 0.01 inches',
            Prefix: '',
            Postfix: 'Days',
            LongText: `For the 30 years from 1951 to 1980, models estimate that locations in {{geoName}}, averaged {{HISTORIC_MEAN}} days per year with no measurable precipitation (dry days)\].

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the average number of days per year with no rain or snow will \[increase / decrease\] to:

-   {{RCP45EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the average number of days per year with no precipitation will further \[increase / decrease\] to:

-   {{RCP85EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.`,
        },
        TMAX100F: {
            Title: 'Annual days with maximum temperature > 100°F',
            Details: 'Annual number of days with a maximum temperature greater than 100°F',
            Prefix: '',
            Postfix: 'Days',
            LongText: `For the 30 years from 1951 to 1980, for locations in {{geoName}}, models estimated an average of {{HISTORIC_MEAN}} days per year when the highest temperature of the day reached 90°F or higher.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the number of days reaching at least 90°F will increase to:

-   an average of {{RCP45EARLY_MEAN}} days per year early this century, from 2011 to 2040;
-   an average of {{RCP45MID_MEAN}} days per year by the middle of this century, from 2041-2070; and
-   an average of {{RCP45LATE_MEAN}} days per year at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the number of days that reach 90°F or higher will further increase to:

-   an average of {{RCP85EARLY_MEAN}} days per year early this century, from 2011 to 2040;
-   an average of {{RCP85MID_MEAN}} days per year by the middle of this century, from 2041-2070; and
-   an average of {{RCP85LATE_MEAN}} days per year at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.`,
        },
        TMAX105F: {
            Title: 'Annual days with maximum temperature > 105°F',
            Details: 'Annual number of days with a maximum temperature greater than 105°F',
            Prefix: '',
            Postfix: 'Days',
            LongText: `For the 30 years from 1951 to 1980, for locations in {{geoName}}, models estimated an average of {{HISTORIC_MEAN}} days per year when the highest temperature of the day reached 90°F or higher.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the number of days reaching at least 90°F will increase to:

-   an average of {{RCP45EARLY_MEAN}} days per year early this century, from 2011 to 2040;
-   an average of {{RCP45MID_MEAN}} days per year by the middle of this century, from 2041-2070; and
-   an average of {{RCP45LATE_MEAN}} days per year at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the number of days that reach 90°F or higher will further increase to:

-   an average of {{RCP85EARLY_MEAN}} days per year early this century, from 2011 to 2040;
-   an average of {{RCP85MID_MEAN}} days per year by the middle of this century, from 2041-2070; and
-   an average of {{RCP85LATE_MEAN}} days per year at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.`,
        },
        TMAX1DAY: {
            Title: 'Annual single highest maximum temperature',
            Details: 'Annual single highest maximum temperature °F',
            Prefix: '',
            Postfix: '°F',
            LongText: `For the 30 years from 1951 to 1980, for locations in {{geoName}}, models estimated that the highest temperature of the year was{{HISTORIC_MEAN}}°F.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the highest temperature of the year at locations in this county will increase to:

-   {{RCP45EARLY_MEAN}}°F during the early part of this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}}°F by the middle of this century, from 2041-2070; and
-   {{RCP45LATE_MEAN}}°F at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the highest temperature of the year will further increase to:

-   {{RCP85EARLY_MEAN}}°F during the early part of this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}}°F by the middle of this century, from 2041-2070; and
-   {{RCP85LATE_MEAN}}°F at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.`,
        },
        TMAX32F: {
            Title: 'Days with maximum temperature below 32°F',
            Details: 'Annual number of icing days (days with a maximum temperature less than 32°F)',
            Prefix: '',
            Postfix: 'Days',
            LongText: `Fewer days with temperatures below freezing means more days with melting, which can increase local flood risk—particularly during rain-on-snow events.

For the 30 years from 1951 to 1980, models estimate that locations in {{geoName}}, averaged {{HISTORIC_MEAN}} days per year when the highest temperature was below 32°F.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the annual number of days with a maximum temperature below 32°F will decrease to:

-   {{RCP45EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP45LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the annual number of days with a maximum temperature below 32°F will further decrease to:

-   {{RCP85EARLY_MEAN}} days early this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}} days by mid-century, from 2041-2070; and
-   {{RCP85LATE_MEAN}} days at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.`,
        },
        TMAX5DAY: {
            Title: 'Annual highest maximum temperature averaged over a 5-day period',
            Details: 'Annual highest maximum temperature averaged over a 5-day period °F',
            Prefix: '',
            Postfix: '°F',
            LongText: `For the 30 years from 1951 to 1980, for locations in {{geoName}}, models estimated the typical afternoon temperature during the hottest week of the year was {{HISTORIC_MEAN}}°F.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the 5-day average maximum temperature during the hottest week of the year at locations in this county will increase to:

-   {{RCP45EARLY_MEAN}}°F during the early part of this century, from 2011 to 2040;
-   {{RCP45MID_MEAN}}°F by the middle of this century, from 2041-2070; and
-   {{RCP45LATE_MEAN}}°F at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the 5-day average maximum temperature during the hottest week of the year will further increase to:

-   {{RCP85EARLY_MEAN}}°F during the early part of this century, from 2011 to 2040;
-   {{RCP85MID_MEAN}}°F by the middle of this century, from 2041-2070; and
-   {{RCP85LATE_MEAN}}°F at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.`,
        },
        TMAX90F: {
            Title: 'Annual days with maximum temperature > 90°F',
            Details: 'Annual number of days with a maximum temperature greater than 90°F',
            Prefix: '',
            Postfix: 'Days',
            LongText: `For the 30 years from 1951 to 1980, for locations in {{geoName}}, models estimated an average of {{HISTORIC_MEAN}} days per year when the highest temperature of the day reached 90°F or higher.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the number of days reaching at least 90°F will increase to:

-   an average of {{RCP45EARLY_MEAN}} days per year early this century, from 2011 to 2040;
-   an average of {{RCP45MID_MEAN}} days per year by the middle of this century, from 2041-2070; and
-   an average of {{RCP45LATE_MEAN}} days per year at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the number of days that reach 90°F or higher will further increase to:

-   an average of {{RCP85EARLY_MEAN}} days per year early this century, from 2011 to 2040;
-   an average of {{RCP85MID_MEAN}} days per year by the middle of this century, from 2041-2070; and
-   an average of {{RCP85LATE_MEAN}} days per year at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.`,
        },
        TMAX95F: {
            Title: 'Annual days with maximum temperature > 95°F',
            Details: 'Annual number of days with a maximum temperature greater than 95°F',
            Prefix: '',
            Postfix: 'Days',
            LongText: `For the 30 years from 1951 to 1980, for locations in {{geoName}}, models estimated an average of {{HISTORIC_MEAN}} days per year when the highest temperature of the day reached 90°F or higher.

If industrial nations make a major effort to limit the amount of heat-trapping gases in the atmosphere, models project the number of days reaching at least 90°F will increase to:

-   an average of {{RCP45EARLY_MEAN}} days per year early this century, from 2011 to 2040;
-   an average of {{RCP45MID_MEAN}} days per year by the middle of this century, from 2041-2070; and
-   an average of {{RCP45LATE_MEAN}} days per year at the end of this century, from 2071 to 2100\.

Alternatively, if industrial nations continue to increase emissions of heat-trapping gases, models project the number of days that reach 90°F or higher will further increase to:

-   an average of {{RCP85EARLY_MEAN}} days per year early this century, from 2011 to 2040;
-   an average of {{RCP85MID_MEAN}} days per year by the middle of this century, from 2041-2070; and
-   an average of {{RCP85LATE_MEAN}} days per year at the end of this century, from 2071 to 2100\.

Note that this interpretation shows the average projections. To see the full range of all projections, check the Chart or Table tabs.`,
        },
    },
    Indicators_Delete_Soon: {
        // HDD: {
        //     Title: 'Heating degree days',
        //     Details:
        //         'Heating degree days (Estimate of heating needed to maintain a comfortable temperature. Calculated as the sum of the degrees less than 65 °F per day per year)',
        //     Prefix: '',
        //     Postfix: 'Degree Days',
        //     LongText: ``,
        // },
        // PR4IN: {
        //     Title: 'Annual days with total precipitation > 4 inches',
        //     Details: 'Annual number of days with total precipitation greater than 4 inches',
        //     Prefix: '',
        //     Postfix: 'Days',
        //     LongText: ``,
        // },
        // PRMAX1DAY: {
        //     Title: 'Annual highest precipitation total for a single day',
        //     Details: 'Annual highest precipitation total for a single day [inches]',
        //     Prefix: '',
        //     Postfix: 'Inches',
        //     LongText: ``,
        // },
        // PRMAX5DAY: {
        //     Title: 'Annual highest precipitation total over a 5-day period',
        //     Details: 'Annual highest precipitation total over a 5-day period [inches]',
        //     Prefix: '',
        //     Postfix: 'Inches',
        //     LongText: ``,
        // },
        // TAVG: {
        //     Title: 'Daily average temperature',
        //     Details: 'Daily average temperature °F',
        //     Prefix: '',
        //     Postfix: '°F',
        //     LongText: ``,
        // },
        // TMAX: {
        //     Title: 'Average daily maximum temperature',
        //     Details: 'Average daily maximum temperature °F',
        //     Prefix: '',
        //     Postfix: '°F',
        //     LongText: ``,
        // },
        // TMIN: {
        //     Title: 'Average daily minimum temperature',
        //     Details: 'Average daily minimum temperature °F',
        //     Prefix: '',
        //     Postfix: '°F',
        //     LongText: ``,
        // },
        // TMIN32F: {
        //     Title: 'Annual frost days',
        //     Details: 'Annual number of frost days (days with a minimum temperature less than 32°F)',
        //     Prefix: '',
        //     Postfix: 'Days',
        //     LongText: ``,
        // },
    },
};

export default enTranslation;
