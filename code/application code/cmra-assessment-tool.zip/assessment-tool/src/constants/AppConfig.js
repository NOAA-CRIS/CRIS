const AppConfig = {
    auth: {
        appItemId: '7c091564683f4edfbad442240de79801',
        clientId: 'KG6zuGKrGA0CAgDa',
        portalUrl: 'https://nationalclimate.maps',
        params: {
            popup: false,
            canHandleCrossOrgSignIn: true,
        },
    },
    googleAnalytics: 'UA-160175705-3',
    webmapIds: {
        dev: '8a9e07dc500442b8b61b182a0a9f6cd1',
        search: '97f080d81cdc401d97e6c196f953ea20',
        search_dev: '7d9ec004789448228b109204500fdd3d',
    },
    datasets: {
        counties: {
            url: 'https://services3.arcgis.com/0Fs3HcaFfvzXvm7w/ArcGIS/rest/services/CMRA_Tool_Dev/FeatureServer/0',
        },
        aiannha: {
            url: 'https://services3.arcgis.com/0Fs3HcaFfvzXvm7w/ArcGIS/rest/services/CMRA_Tool_Dev/FeatureServer/1',
        },
    },
    searchZoom: 13,
    zoomToGeomExtentFactor: 1.5,
    rendererDataExtentFactor: 1.5,
    renderer: {
        type: 'classBreaks',
        visualVariables: [
            {
                type: 'sizeInfo',
                valueExpression: '$view.scale',
                stops: [
                    {
                        size: 2,
                        value: 421728,
                    },
                    {
                        size: 1,
                        value: 1317901,
                    },
                    {
                        size: 0.5,
                        value: 5271605,
                    },
                    {
                        size: 0,
                        value: 10543209,
                    },
                ],
                target: 'outline',
            },
        ],
        classBreakInfos: [
            {
                classMaxValue: 9007199254740991,
                symbol: {
                    type: 'esriSFS',
                    color: [170, 170, 170, 255],
                    outline: {
                        type: 'esriSLS',
                        color: [194, 194, 194, 64],
                        width: 0.375,
                        style: 'esriSLSSolid',
                    },
                    style: 'esriSFSSolid',
                },
            },
        ],
        field: '',
        minValue: -9007199254740991,
    },
    slrRenderer: {
        type: 'classBreaks',
        visualVariables: [
            {
                type: 'sizeInfo',
                valueExpression: '$view.scale',
                stops: [
                    {
                        size: 2,
                        value: 1367724,
                    },
                    {
                        size: 1,
                        value: 4274137,
                    },
                    {
                        size: 0.5,
                        value: 17096548,
                    },
                    // {
                    //     size: 0,
                    //     value: 34193096,
                    // },
                ],
                target: 'outline',
            },
        ],
        classBreakInfos: [
            {
                label: 'Sea Level Rise',
                classMaxValue: 100000,
                symbol: {
                    type: 'esriSFS',
                    color: [158, 202, 225, 0],
                    outline: {
                        type: 'esriSLS',
                        color: [0, 112, 255, 255],
                        width: 0.81,
                        style: 'none',
                        // style: 'esriSLSSolid',
                    },
                    style: 'esriSFSSolid',
                },
            },
        ],
        field: 'RCP85LATE_MAX_SLR',
        minValue: -100000,
    },
    urls: {
        report: 'https://cris.ncics.org/reports',
        toolMethodology: 'https://screeningtool.geoplatform.gov/en/methodology',
        bcatInfo: 'https://www.fema.gov/emergency-managers/risk-management/building-science/bcat',
        userGuide: 'https://resilience.climate.gov/pages/user-guide',
        portal: 'https://resilience.climate.gov/',
        dataSources: 'https://resilience.climate.gov/pages/data-sources',
    },
};

export default AppConfig;
