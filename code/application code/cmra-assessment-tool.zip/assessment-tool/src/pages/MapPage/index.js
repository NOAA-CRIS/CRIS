export { default } from './MapPage';
