export { default } from './MobilePage';
