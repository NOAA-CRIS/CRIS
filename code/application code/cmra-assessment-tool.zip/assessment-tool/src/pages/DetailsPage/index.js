export { default } from './DetailsPage';
