// Framework and third-party non-ui
import React from 'react';

// App components
import Header from './components/Header';
import './components/Header/Header.scss';

// Hooks, context, and constants
import { useAppContext } from './context/AppContextSimple';

import logo from './images/logo.png';
import './App.scss';
import MapPage from './pages/MapPage';
import DetailsPage from './pages/DetailsPage';
import AppRoutes from './constants/AppRoutes';

const App = () => {
    const { page } = useAppContext();
    const APP_BASE_URL = import.meta.env.VITE_base_url || import.meta.env.VITE_BASE_URL || '/';

    return (
        <div className="app-container">
            <Header />
            {page === AppRoutes.detailsPage && <DetailsPage />}
            <MapPage active={page === AppRoutes.mapPage} />
            <div className="app-container__window-too-small">
                <div className="app-container__window-too-small-text">
                    <a className="app-container__window-too-small-link" href={APP_BASE_URL}>
                        <img className="app-container__window-too-small-img" src={logo} alt={'CMRA Logo'} width="50" />
                        Climate Mapping For Resilience and Adaptation
                    </a>
                    <p>
                        The CMRA assessment tool currently does not support mobile devices or screens that have a
                        resolution less than 720px in width.
                    </p>
                    <p className="app-container__window-too-small-outlinks">
                        <a href="https://resilience.climate.gov/" target="_blank" rel="noreferrer">
                            View CMRA Portal
                        </a>
                        <a href="https://resilience.climate.gov/pages/user-guide" target="_blank" rel="noreferrer">
                            Access User Guide
                        </a>
                    </p>
                </div>
            </div>
        </div>
    );
};

export default App;
