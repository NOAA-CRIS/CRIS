export { default } from './HazardItem';
