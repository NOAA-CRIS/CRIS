export { default } from './HazardList';
