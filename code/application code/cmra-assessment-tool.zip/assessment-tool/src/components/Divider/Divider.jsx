// Framework and third-party non-ui
import React from 'react';

import './Divider.scss';

const Divider = () => {
    return <div className="divider"></div>;
};

export default Divider;
