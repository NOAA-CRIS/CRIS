// Framework and third-party non-ui
import { Button, ButtonGroup, Radio } from '@trussworks/react-uswds';
import React from 'react';

// Hooks, context, and constants
import { useTranslation } from 'react-i18next';
import ScreeningData from '../../constants/ScreeningData';
import { useAppContext } from '../../context/AppContextSimple';

// App components

// Component specific modules (Component-styled, etc.)
import './StandardGeographySelect.scss';

// Third-party components (buttons, icons, etc.)

const StandardGeographySelect = () => {
    const [t] = useTranslation();
    const { standardGeography, updateStandardGeography } = useAppContext();

    return (
        <div className="standardGeographySelect">
            <h2 className="font-serif-2md">{t('StandardGeographySelect.Info')}</h2>
            <ButtonGroup className="standardGeographySelect-button-group" type="segmented">
                <Button
                    outline={standardGeography !== ScreeningData.standardGeographies.county}
                    onClick={() => {
                        updateStandardGeography(ScreeningData.standardGeographies.county);
                    }}
                >
                    <span className="standardGeographySelect-btn-label">
                        <span className="standardGeographySelect-btn-radio"></span>
                        {t('Data.StandardGeographies.COUNTY')}
                    </span>
                </Button>

                <Button
                    outline={standardGeography !== ScreeningData.standardGeographies.aiannha}
                    onClick={() => {
                        updateStandardGeography(ScreeningData.standardGeographies.aiannha);
                    }}
                >
                    <span className="standardGeographySelect-btn-label">
                        <span className="standardGeographySelect-btn-radio"></span>
                        {t('Data.StandardGeographies.aiannha')}
                    </span>
                </Button>
            </ButtonGroup>
        </div>
    );
};

export default StandardGeographySelect;
