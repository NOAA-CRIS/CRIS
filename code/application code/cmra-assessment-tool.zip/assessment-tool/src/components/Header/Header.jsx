// Framework and third-party non-ui
import React from 'react';

// Hooks, context, and constants
import { useTranslation } from 'react-i18next';
import { useAppContext } from '../../context/AppContextSimple';
import AppConfig from '../../constants/AppConfig';

// App components
import logo from '../../images/logo.png';

// Component specific modules (Component-styled, etc.)
import './Header.scss';

// Third-party components (buttons, icons, etc.)
import { Button, Tooltip, Icon } from '@trussworks/react-uswds';
import ScreeningData from '../../constants/ScreeningData';
import ClipLoader from 'react-spinners/ClipLoader';

const Header = () => {
    const [t] = useTranslation();
    const [menuOpen, setMenuOpen] = React.useState(false);
    const { areaOfInterestInfo, standardGeography } = useAppContext();
    const VITE_APP_VERSION = import.meta.env.VITE_APP_VERSION;
    const APP_BASE_URL = import.meta.env.VITE_base_url || import.meta.env.VITE_BASE_URL || '/';

    // INFO: this needs to match the breakpoint in Header.scss
    const MOBILE_BREAKPOINT = 1140;

    const handleTitleClick = () => {};
    const handleReportClick = () => {
        if (!areaOfInterestInfo?.geoId) {
            return;
        }
        const geoPath = standardGeography === ScreeningData.standardGeographies.county ? 'county' : 'tribal';
        const geoId = areaOfInterestInfo?.geoId?.toLowerCase();
        const url = `${AppConfig.urls.report}/${geoPath}/${geoId}.html`;
        window.open(url, '_blank');
    };

    // onload set initial state menuOpen (for tabindex, aria-label)
    React.useEffect(() => {
        if (window.innerWidth > MOBILE_BREAKPOINT) {
            setMenuOpen(true);
        } else {
            setMenuOpen(false);
        }
    }, []);

    // onresize set state menuOpen (for tabindex, aria-label)
    React.useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth > MOBILE_BREAKPOINT) {
                setMenuOpen(true);
                let child = document.querySelector('.e-header__menu-toggle');
                if (child) {
                    child.classList.remove('active');
                }
            } else if (window.innerWidth <= MOBILE_BREAKPOINT) {
                // Only set to false on small screens, don't interfere with manual toggle
                setMenuOpen(false);
                let child = document.querySelector('.e-header__menu-toggle');
                if (child) {
                    child.classList.remove('active');
                }
            }
        };

        // listen
        window.addEventListener('resize', handleResize);

        // cleanup
        return () => {
            window.removeEventListener('resize', handleResize);
        };
    }, []);

    const reportButton = (
        <Button
            className="e-header__report-button usa-button usa-button--outline usa-button--inverse"
            title={!areaOfInterestInfo?.geoId ? t('Header.ButtonDisabledNoSelection') : ''}
            onClick={handleReportClick}
            disabled={!areaOfInterestInfo?.geoId}
        >
            {t('Header.Button')}
        </Button>
    );

    return (
        <header className="e-header">
            <div className="e-header-start">
                <div className="e-header__logo">
                    <a href={APP_BASE_URL}>
                        <img className="e-header__logo-img" src={logo} alt={'CMRA Logo'} />
                    </a>
                </div>
                <div className="e-header__app-title" onClick={handleTitleClick}>
                    <a href={APP_BASE_URL}>
                        <span>{t('App.Title')}</span>
                    </a>
                    <span className="e-header__app-version">{`v${VITE_APP_VERSION}`}</span>
                </div>
            </div>
            <div className="e-header-end">
                <Button
                    onClick={(e) => {
                        let classTransitionTimer;
                        let child = e.currentTarget.querySelector('.e-header__menu-toggle');

                        if (classTransitionTimer) {
                            clearTimeout(classTransitionTimer);
                        }

                        if (menuOpen) {
                            child.classList.remove('active');

                            // temporarily give transition class
                            child.classList.add('active--transition-out');

                            classTransitionTimer = setTimeout(() => {
                                // remove temporary transition class
                                child.classList.remove('active--transition-out');
                            }, 600);
                            setMenuOpen(false);
                        } else {
                            child.classList.add('active');
                            setMenuOpen(true);
                        }
                    }}
                    className="e-header__menu-button"
                    aria-label={menuOpen ? t('Header.MobileMenuBtn.Open') : t('Header.MobileMenuBtn.Close')}
                >
                    <Icon.Menu className="e-header__menu-toggle" size={4} />
                </Button>
                <nav>
                    <ul>
                        <li>
                            {/* if menu open give tab index 0 else give -1 */}
                            <a
                                href={AppConfig.urls.dataSources}
                                target="_blank"
                                rel="noopener noreferrer"
                                tabIndex={menuOpen ? -1 : 0}
                            >
                                {t('App.DataSources')}
                            </a>
                        </li>
                        <li>
                            <a
                                href={AppConfig.urls.portal}
                                target="_blank"
                                rel="noopener noreferrer"
                                tabIndex={menuOpen ? -1 : 0}
                            >
                                {t('App.LinkToPortal')}
                            </a>
                        </li>
                        <li>
                            <a
                                href={AppConfig.urls.userGuide}
                                target="_blank"
                                rel="noopener noreferrer"
                                tabIndex={menuOpen ? -1 : 0}
                            >
                                {t('App.UserGuide')}
                            </a>
                        </li>
                        <li>
                            <a
                                onClick={(e) => {
                                    e.preventDefault();
                                    handleReportClick();
                                }}
                                href={AppConfig.urls.userGuide}
                                target="_blank"
                                rel="noopener noreferrer"
                                tabIndex={menuOpen ? -1 : 0}
                                className="e-header__report-button"
                                disabled={!areaOfInterestInfo?.geoId}
                                title={!areaOfInterestInfo?.geoId ? t('Header.ButtonDisabledNoSelection') : ''}
                            >
                                {t('Header.Button')}
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </header>
    );
};

Header.propTypes = {};
export default Header;
