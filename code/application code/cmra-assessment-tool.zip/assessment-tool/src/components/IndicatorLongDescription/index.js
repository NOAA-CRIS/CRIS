export { default } from './IndicatorLongDescription';
