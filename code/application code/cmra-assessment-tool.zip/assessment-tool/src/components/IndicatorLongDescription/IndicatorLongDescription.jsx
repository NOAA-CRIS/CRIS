// Framework and third-party non-ui
import React, { useMemo } from 'react';
import { marked } from 'marked';

// Hooks, context, and constants
import { useTranslation } from 'react-i18next';
import { useAppContext } from '../../context/AppContextSimple';
import AppConfig from '../../constants/AppConfig';

// App components
import logo from '../../images/logo.png';

// Component specific modules (Component-styled, etc.)
import './IndicatorLongDescription.scss';

// Third-party components (buttons, icons, etc.)
import { Button, Tooltip, Icon } from '@trussworks/react-uswds';
import ScreeningData from '../../constants/ScreeningData';
import ClipLoader from 'react-spinners/ClipLoader';

const IndicatorLongDescription = ({ selectedIndicator }) => {
    const { t } = useTranslation();
    const { areaOfInterestInfo } = useAppContext();

    const getMarkdownText = () => {
        return {
            __html: marked(
                t(`Indicators.${selectedIndicator.id}.LongText`, {
                    ...selectedIndicator,
                    geoName: areaOfInterestInfo.geoName,
                })
            ),
        };
    };
    const pr99Elements = useMemo(() => {
        const data = {
            HISTORIC_MEAN: selectedIndicator.HISTORIC_MEAN,
            geoName: areaOfInterestInfo.geoName,
        };
        return <h2>{t('Indicators.PR99.LongText', data)}</h2>;
    }, [selectedIndicator, areaOfInterestInfo, t]);

    if (selectedIndicator.id === 'PR99') {
        return pr99Elements;
    }

    return <div dangerouslySetInnerHTML={getMarkdownText()} />;
};

IndicatorLongDescription.propTypes = {};
export default IndicatorLongDescription;
