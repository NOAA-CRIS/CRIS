export { default } from './IndicatorDetails';
