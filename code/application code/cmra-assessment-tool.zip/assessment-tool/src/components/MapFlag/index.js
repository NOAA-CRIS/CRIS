export { default } from './MapFlag';
