export { default } from './IndicatorTable.jsx';
