// Framework and third-party non-ui
import React from 'react';

// Config
import AppConfig from '../../constants/AppConfig';

// Hooks, context, and constants
import { useTranslation } from 'react-i18next';
import { useAppContext } from '../../context/AppContextSimple';
import ScreeningData from '../../constants/ScreeningData';

// Component specific modules (Component-styled, etc.)
import './MapLegend.scss';

// Third-party components (buttons, icons, etc.)
import { Icon } from '@trussworks/react-uswds';

// Images
import ExtremeTemperatureIcon from '../../images/hazard_icons/extreme_temperature.png';
import DroughtIcon from '../../images/hazard_icons/drought.png';
import FireIcon from '../../images/hazard_icons/fire.png';
import FloodingCostalIcon from '../../images/hazard_icons/flooding_costal.png';
import FloodingInlandIcon from '../../images/hazard_icons/flooding_inland.png';

const MapLegend = ({ colorRamp, values }) => {
    const [t] = useTranslation();
    const { selectedIndicatorId, standardGeography, selectedHazard, areaOfInterestInfo } = useAppContext();

    const getHazardIcons = (hazardId) => {
        switch (hazardId) {
            case 'extreme_temperature':
                return <img src={ExtremeTemperatureIcon} alt="Extreme Temperature Icon" />;
            case 'drought':
                return <img src={DroughtIcon} alt="Drought Icon" />;
            case 'fire':
                return <img src={FireIcon} alt="Fire Icon" />;
            case 'flooding_inland':
                return <img src={FloodingInlandIcon} alt="Inland Flooding Icon" />;
            case 'flooding_costal':
                return <img src={FloodingCostalIcon} alt="Costal Flooding Icon" />;
            // no default
        }
    };

    return (
        <div className="mapLegend-container">
            <div className="mapLegend-row">
                <div className="mapLegend-icon">{getHazardIcons(selectedHazard)}</div>
                <div className="mapLegend-header font-sans-2xs">
                    {t(`Indicators.${selectedIndicatorId}.Title`, {
                        standardGeography: t(`Data.StandardGeographies.${standardGeography}`).toLowerCase(),
                    })}
                </div>
            </div>
            {selectedIndicatorId === ScreeningData.seaLevelRiseId && (
                <div className="mapLegend-values-container mapLegend__slr-legend">
                    <div className="mapLegend-row">
                        <div className="mapLegend-row">
                            <span className="blue-slr"></span>
                            <span>Sea Level Rise</span>
                        </div>
                        <div className="mapLegend-row">
                            <span className="gray-slr"></span>
                            <span>Levee Areas</span>
                        </div>
                    </div>
                </div>
            )}
            {selectedIndicatorId !== ScreeningData.seaLevelRiseId && (
                <>
                    <div className="mapLegend-row">
                        <div className="mapLegend-values-container">
                            {values?.map((value, index) => (
                                <div key={`map-legend-value-${index}`}>{value}</div>
                            ))}
                        </div>
                    </div>
                    <div className="mapLegend-row">
                        <div className={`mapLegend-colors-container ${colorRamp}`}></div>
                    </div>
                </>
            )}

            {areaOfInterestInfo?.buildingCode && (
                <div className="mapLegend-row">
                    <div className={`mapLegend-building-code-container`}>
                        <a href={`${AppConfig.urls.bcatInfo}`} target="_blank" rel="noreferrer">
                            {t('Flags.BuildingCode', { buildingCode: areaOfInterestInfo?.buildingCode || 'N/A' })}
                            <Icon.Launch className="detailsPage__header-end-icon" size={2} />
                        </a>
                    </div>
                </div>
            )}
        </div>
    );
};

MapLegend.propTypes = {};
export default MapLegend;
